"use client";
import Link from "next/link";

export default function LandingPage() {
  return (
    <main className="flex flex-col min-h-screen items-center justify-center px-4 text-center bg-gray-50">
      <h1 className="text-4xl md:text-5xl font-bold mb-4">DSRT Photo Editor</h1>
      <p className="text-gray-600 mb-6 max-w-md text-base md:text-lg">
        Aplikasi edit foto manual berbasis web. Ringan, gratis, dan bisa diinstal sebagai aplikasi di Android/Desktop.
      </p>
      <Link
        href="/editor"
        className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 text-sm md:text-base"
      >
        Buka Editor
      </Link>
      <p className="mt-6 text-xs text-gray-400">
        © 2025 DSRT Project – Dibuat dengan GPT
      </p>
    </main>
  );
}