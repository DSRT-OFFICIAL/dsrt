"use client";
import dynamic from "next/dynamic";
import "tui-image-editor/dist/tui-image-editor.css";

const ImageEditor = dynamic(() => import("@toast-ui/react-image-editor"), {
  ssr: false,
});

const myTheme = {}; // Pakai tema default

const editorOptions = {
  includeUI: {
    loadImage: {
      path: "",
      name: "SampleImage",
    },
    theme: myTheme,
    menu: [
      "crop", "flip", "rotate", "draw", "shape", "icon",
      "text", "mask", "filter"
    ],
    initMenu: "filter",
    uiSize: {
      width: "100%",
      height: "700px",
    },
    menuBarPosition: "bottom",
  },
  cssMaxHeight: 600,
  cssMaxWidth: 1000,
  selectionStyle: {
    cornerSize: 20,
    rotatingPointOffset: 70,
  },
  usageStatistics: false,
};

export default function EditorPage() {
  return (
    <div className="p-2 md:p-4">
      <h1 className="text-2xl font-semibold mb-2 text-center">
        DSRT Photo Editor – Studio Manual
      </h1>
      <ImageEditor {...editorOptions} />
    </div>
  );
}